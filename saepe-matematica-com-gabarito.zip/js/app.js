const ANOS = ['2018','2019','2021','2022','2026'];
const LETRAS = ['A','B','C','D','E'];
const $ = id => document.getElementById(id);
const nomeProva = a => a === '2026' ? 'Avaliação Formativa 2026' : 'SAEPE ' + a;
const chave = q => q.ano + '-' + q.num;

// ---- gabarito (só vale se preenchido em js/gabarito.js) ----
function gab(q){
  const g = (typeof GABARITO !== 'undefined' && GABARITO[q.ano]) || {};
  const v = String(g[String(q.num)] || '').trim().toUpperCase();
  return LETRAS.includes(v) ? v : '';
}

function expl(q){
  const e = (typeof EXPLICACOES !== 'undefined' && EXPLICACOES[q.ano]) || {};
  return e[String(q.num)] || '';
}
function blocoExplicacao(q){
  const t = expl(q); if (!t) return '';
  return '<div class="expl"><b>📐 Explicação</b><p>' + t + '</p></div>';
}

// ---- imagem com aviso se não for encontrada ----
function imgErro(el){
  const arq = el.getAttribute('data-arq');
  const d = document.createElement('div');
  d.className = 'erro-img';
  d.innerHTML = '⚠️ <b>IMAGEM NÃO ENCONTRADA</b><br>Arquivo esperado:<code>' + arq + '</code>';
  el.replaceWith(d);
}
function imgHTML(q){
  return '<div class="qimg"><img src="' + q.img + '" data-arq="' + q.img + '" loading="lazy" alt="' +
    nomeProva(q.ano) + ' - questão ' + q.num + '" onerror="imgErro(this)"></div>';
}
function cabecalho(q){
  return '<div class="qh"><span class="tag t1">Questão ' + String(q.num).padStart(2,'0') + '</span>' +
    '<span class="tag t2">' + nomeProva(q.ano) + '</span>' +
    (q.cod ? '<span class="tag t3">' + q.cod + '</span>' : '') + '</div>';
}

// ---- navegação ----
const PAGS = ['home','banco','sim','mz','dep'];
function ir(id){
  PAGS.forEach(p => $('p-' + p).classList.toggle('on', p === id));
  document.querySelectorAll('nav button').forEach((b,i) => b.classList.toggle('on', PAGS[i] === id));
  if (id === 'banco') filtrar();
  if (id === 'dep') desempenho();
  window.scrollTo({top:0});
}

// ---- início ----
function montarHome(){
  const ic = {'2018':'📘','2019':'📙','2021':'📕','2022':'📗','2026':'⭐'};
  $('cards').innerHTML = ANOS.map(a => {
    const n = QUESTOES.filter(q => q.ano === a).length;
    return '<div class="card" onclick="abrirAno(\'' + a + '\')"><div class="ic">' + ic[a] + '</div><b>' + a +
      '</b><small>' + (a === '2026' ? 'Avaliação Formativa' : 'Prova SAEPE') + '</small><span class="n">' + n + ' questões</span></div>';
  }).join('');
  $('total').textContent = QUESTOES.length;
}
function abrirAno(a){ $('f-ano').value = a; ir('banco'); }

// ---- banco de questões ----
const marcadas = {};   // respostas marcadas no banco
function filtrar(){
  const ano = $('f-ano').value;
  const b = $('f-busca').value.trim().toLowerCase();
  const lista = QUESTOES.filter(q => {
    if (ano && q.ano !== ano) return false;
    if (b){
      if (/^\d{1,2}$/.test(b)){ if (String(q.num) !== String(parseInt(b))) return false; }
      else if (!(q.cod.toLowerCase().includes(b) || q.ano.includes(b) || q.texto.toLowerCase().includes(b))) return false;
    }
    return true;
  });
  $('cont').textContent = lista.length + ' questão(ões) exibida(s)';
  $('lista').innerHTML = lista.length ? lista.map(cartao).join('') : '<div class="aviso">Nenhuma questão encontrada.</div>';
}
function limpar(){ $('f-ano').value = ''; $('f-busca').value = ''; filtrar(); }

function botoes(q, sel, revelado){
  const g = gab(q);
  return q.alts.map(l => {
    let c = '';
    if (revelado && g){ if (l === g) c = 'ok'; else if (l === sel) c = 'no'; }
    else if (l === sel) c = 'sel';
    return '<button class="' + c + '" data-k="' + chave(q) + '" data-l="' + l + '">' + l + '</button>';
  }).join('');
}
const reveladas = {};
function cartao(q){
  const k = chave(q);
  return '<div class="q" id="q-' + k + '">' + cabecalho(q) + imgHTML(q) +
    '<div class="resp" id="r-' + k + '">' + botoes(q, marcadas[k], reveladas[k]) + '</div>' +
    '<div class="acoes"><button class="btn bs" onclick="mostrarGab(\'' + k + '\')">✔ Ver gabarito</button></div>' +
    '<div id="m-' + k + '"></div></div>';
}
function achar(k){ return QUESTOES.find(q => chave(q) === k); }
function atualizarCartao(k){
  const q = achar(k);
  $('r-' + k).innerHTML = botoes(q, marcadas[k], reveladas[k]);
}
function mostrarGab(k){
  const q = achar(k), g = gab(q), m = $('m-' + k);
  reveladas[k] = true; atualizarCartao(k);
  m.innerHTML = g ? '<div class="msg ok">Resposta correta: <b>' + g + '</b></div>' + blocoExplicacao(q)
                  : '<div class="msg">Gabarito não cadastrado para esta questão (preencha em js/gabarito.js).</div>';
}
document.addEventListener('click', e => {
  const b = e.target.closest('.resp button'); if (!b) return;
  const k = b.dataset.k, l = b.dataset.l;
  if (b.closest('#p-sim')){ simResp[simI] = l; simRender(); return; }
  marcadas[k] = l; atualizarCartao(k);
  const q = achar(k), g = gab(q);
  if (g){ reveladas[k] = true; atualizarCartao(k);
    $('m-' + k).innerHTML = (l === g ? '<div class="msg ok">✅ Correto! Resposta: <b>' + g + '</b></div>'
                                     : '<div class="msg no">❌ Resposta correta: <b>' + g + '</b></div>') + blocoExplicacao(q); }
});

// ---- simulado ----
let simQs = [], simI = 0, simResp = {}, simT0 = 0, simTimer = null;
function simIniciar(){
  const ano = $('s-ano').value;
  let pool = QUESTOES.filter(q => !ano || q.ano === ano);
  if ($('s-alea').checked) pool = pool.map(q => [Math.random(), q]).sort((a,b) => a[0]-b[0]).map(x => x[1]);
  const n = Math.max(1, Math.min(parseInt($('s-n').value) || 10, pool.length));
  simQs = pool.slice(0, n); simI = 0; simResp = {}; simT0 = Date.now();
  $('sim-cfg').style.display = 'none'; $('sim-res').style.display = 'none'; $('sim-run').style.display = 'block';
  clearInterval(simTimer);
  simTimer = setInterval(() => {
    const s = Math.floor((Date.now() - simT0) / 1000);
    $('sim-tempo').textContent = '⏱ ' + String(Math.floor(s/60)).padStart(2,'0') + ':' + String(s%60).padStart(2,'0');
  }, 1000);
  simRender();
}
function simRender(){
  const q = simQs[simI], tot = simQs.length;
  $('sim-pos').textContent = 'Questão ' + String(simI+1).padStart(2,'0') + ' de ' + String(tot).padStart(2,'0');
  $('sim-bar').style.width = ((simI+1)/tot*100) + '%';
  $('sim-corpo').innerHTML = cabecalho(q) + imgHTML(q) +
    '<div class="resp">' + q.alts.map(l => '<button class="' + (simResp[simI] === l ? 'sel' : '') + '" data-k="' + chave(q) + '" data-l="' + l + '">' + l + '</button>').join('') + '</div>';
  $('sim-ant').disabled = simI === 0;
  $('sim-prox').style.display = simI < tot-1 ? 'inline-flex' : 'none';
  $('sim-fim').style.display = simI === tot-1 ? 'inline-flex' : 'none';
}
function simNav(d){ simI = Math.max(0, Math.min(simQs.length-1, simI + d)); simRender(); window.scrollTo({top:0}); }
function simFinalizar(){
  clearInterval(simTimer);
  let resp = 0, corr = 0, acertos = 0;
  const linhas = simQs.map((q,i) => {
    const r = simResp[i] || '', g = gab(q);
    if (r) resp++;
    let cls = 'nd', sim = '–';
    if (g){ corr++; if (r === g){ acertos++; cls = 'ok'; sim = '✓'; } else { cls = 'no'; sim = '✗'; } }
    return '<details class="li2"><summary><span class="b ' + cls + '">' + sim + '</span><span style="flex:1"><b>' + nomeProva(q.ano) +
      ' • Questão ' + String(q.num).padStart(2,'0') + '</b></span><span>Sua resposta: <b>' + (r || 'em branco') +
      '</b> | Gabarito: <b>' + (g || 'não cadastrado') + '</b></span></summary>' + imgHTML(q) + blocoExplicacao(q) + '</details>';
  }).join('');
  const t = Math.floor((Date.now() - simT0)/1000);
  let topo;
  if (corr > 0){
    const pct = Math.round(acertos / corr * 100);
    topo = '<div class="nota">' + pct + '%</div><div class="kpis"><div class="kpi"><b>' + acertos + '</b><small>Acertos</small></div><div class="kpi"><b>' +
      (corr - acertos) + '</b><small>Erros</small></div><div class="kpi"><b>' + Math.floor(t/60) + 'min ' + t%60 + 's</b><small>Tempo</small></div></div>' +
      (corr < simQs.length ? '<div class="aviso">' + (simQs.length - corr) + ' questão(ões) sem gabarito cadastrado não entraram na nota.</div>' : '');
  } else {
    topo = '<div class="aviso">O <b>gabarito ainda não foi cadastrado</b> (os PDFs enviados não o trazem), então não é possível calcular acertos. ' +
      'Suas respostas estão listadas abaixo. Preencha o arquivo <b>js/gabarito.js</b> para ativar a correção.</div><div class="kpis"><div class="kpi"><b>' + resp +
      '/' + simQs.length + '</b><small>Respondidas</small></div><div class="kpi"><b>' + Math.floor(t/60) + 'min ' + t%60 + 's</b><small>Tempo</small></div></div>';
  }
  try {
    const h = JSON.parse(localStorage.getItem('saepe_hist') || '[]');
    h.push({data: new Date().toLocaleString('pt-BR'), total: simQs.length, resp, corr, acertos});
    localStorage.setItem('saepe_hist', JSON.stringify(h.slice(-30)));
  } catch(e) {}
  $('sim-run').style.display = 'none'; $('sim-res').style.display = 'block';
  $('sim-res').innerHTML = '<div class="res"><h3 class="t">📊 Resultado</h3>' + topo + '<p class="cont">Toque em uma questão para ver o enunciado e a explicação.</p><div class="lista">' + linhas + '</div>' +
    '<div style="margin-top:18px" class="acoes"><button class="btn bp" onclick="simNovo()">🔄 Novo simulado</button></div></div>';
  window.scrollTo({top:0});
}
function simNovo(){ $('sim-cfg').style.display = 'grid'; $('sim-res').style.display = 'none'; $('sim-run').style.display = 'none'; }

// ---- matriz ----
function montarMatriz(){
  $('mz').innerHTML = ['matriz-1','matriz-2'].map(n => {
    const a = 'imagens/matriz/' + n + '.png';
    return '<img src="' + a + '" data-arq="' + a + '" alt="Matriz de referência" onerror="imgErro(this)">';
  }).join('');
}

// ---- desempenho ----
function desempenho(){
  let h = [];
  try { h = JSON.parse(localStorage.getItem('saepe_hist') || '[]'); } catch(e) {}
  if (!h.length){ $('dep').innerHTML = '<div class="aviso">Nenhum simulado realizado ainda neste navegador.</div>'; return; }
  $('dep').innerHTML = '<div class="hist">' + h.slice().reverse().map(x =>
    '<div class="hi"><span>' + x.data + '</span><span>' + x.resp + '/' + x.total + ' respondidas</span><b>' +
    (x.corr ? (x.acertos + ' acertos em ' + x.corr + ' corrigidas') : 'sem gabarito cadastrado') + '</b></div>').join('') + '</div>';
}

montarHome(); montarMatriz(); filtrar();

// ---- ampliar imagem ao tocar ----
document.addEventListener('click', e => {
  const im = e.target.closest('.qimg img'); if (!im) return;
  const z = document.createElement('div'); z.className = 'zoom';
  z.innerHTML = '<b>✕ toque para fechar</b><img src="' + im.src + '" alt="">';
  z.onclick = () => z.remove();
  document.body.appendChild(z);
});
