// Questões de Matemática extraídas das provas originais (texto e imagens recortadas dos PDFs).
// Cada questão é exibida pela imagem original.
const QUESTOES = [
 {
  "ano": "2018",
  "num": 14,
  "cod": "M120406H6",
  "img": "imagens/2018/questao14.png",
  "alts": [
   "A",
   "B",
   "C",
   "D",
   "E"
  ],
  "texto": "14) (M120406H6) Qual dos desenhos abaixo representa a planificação de um cubo? A) B) C) D) E)"
 },
 {
  "ano": "2018",
  "num": 15,
  "cod": "M110097H6",
  "img": "imagens/2018/questao15.png",
  "alts": [
   "A",
   "B",
   "C",
   "D",
   "E"
  ],
  "texto": "15) (M110097H6) Uma empresa aérea realizou uma pesquisa entre seus clientes para saber quais eram os seus destinos preferidos. Dos 300 clientes entrevistados, 40% optaram pela Irlanda. Quantos clientes entrevistados preferem a Irlanda como destino? A) 12 B) 40 C) 120 D) 180 E) 260 BL01M12 5"
 },
 {
  "ano": "2018",
  "num": 16,
  "cod": "M120413H6",
  "img": "imagens/2018/questao16.png",
  "alts": [
   "A",
   "B",
   "C",
   "D",
   "E"
  ],
  "texto": "16) (M120413H6) A tabela abaixo apresenta a quantidade de vitaminas do tipo A, B1 e B2 em cada porção de 100 gramas de algumas frutas. Frutas Vitamina A Vitamina B1 Vitamina B2 (100 g) (mcg) (mcg) (mcg) Abacaxi 5 80 128 Banana 10 92 103 Maçã 4 45 100 Graviola 2 100 50 Abacate 20 70 100 Melancia 23 20 30 Mangaba 30 40 40 Disponível em: <http://www.ebah.com.br/content/ABAAAesJ0AB/frutas-hortalicas#>. Acesso em: 13 jul. 2017. * Adaptado para fins didáticos. De acordo com essa tabela, a variação máxima das quantidades de vitamina A, B1 e B2 nessas frutas são, respectivamente, A) 2 mcg, 20 mcg e 30 mcg. B) 7 mcg, 8 mcg e 25 mcg. C) 25 mcg, 40 mcg e 88 mcg. D) 28 mcg, 80 mcg e 98 mcg. E) 30 mcg, 100 mcg e 128 mcg."
 },
 {
  "ano": "2018",
  "num": 17,
  "cod": "M100070C2",
  "img": "imagens/2018/questao17.png",
  "alts": [
   "A",
   "B",
   "C",
   "D",
   "E"
  ],
  "texto": "17) (M100070C2) O volume (V) em um reservatório de água varia em função do tempo (t), em horas, conforme representado no gráfico da função quadrática abaixo. De acordo com esse gráfico, em quantas horas esse reservatório atinge seu volume máximo? A) 6 B) 12 C) 24 D) 144 E) 288 BL01M12 6"
 },
 {
  "ano": "2018",
  "num": 18,
  "cod": "M120382H6",
  "img": "imagens/2018/questao18.png",
  "alts": [
   "A",
   "B",
   "C",
   "D",
   "E"
  ],
  "texto": "18) (M120382H6) Cláudia foi a um teatro e observou que a distribuição das cadeiras para a plateia foi feita da seguinte maneira: a primeira fileira, a mais próxima ao palco, possui 6 assentos, a segunda fileira, 8 assentos e assim sucessivamente, de forma que as quantidades de assentos em cada fileira seguem uma progressão aritmética. Claudia sentou-se em uma cadeira da última fileira dessa plateia, a qual continha 26 assentos. De acordo com essa distribuição, a quantidade total de cadeiras para a plateia nesse teatro era de A) 11. Dados: an = a1 + (n – 1). r B) 40. C) 70. D) 176. ^a1 + anh n Sn = E) 289. 2"
 },
 {
  "ano": "2018",
  "num": 19,
  "cod": "M120183H6",
  "img": "imagens/2018/questao19.png",
  "alts": [
   "A",
   "B",
   "C",
   "D",
   "E"
  ],
  "texto": "19) (M120183H6) A reta t, cuja equação reduzida é dada por y = kx + z, possui coeficientes k > 0 e z < 0. O gráfico que representa essa reta é A) y B) y t x x t C) y D) y t t x x E) y x t BL01M12 7"
 },
 {
  "ano": "2018",
  "num": 20,
  "cod": "M100344ES",
  "img": "imagens/2018/questao20.png",
  "alts": [
   "A",
   "B",
   "C",
   "D",
   "E"
  ],
  "texto": "20) (M100344ES) A previsão do tempo para uma cidade brasileira foi noticiada da seguinte maneira: “Durante a madrugada a temperatura diminuiu, permanecendo constante pela manhã, mas aumentou no período da tarde”. Qual dos gráficos abaixo melhor representa a situação descrita nesse texto? A) B) C) D) E)"
 },
 {
  "ano": "2018",
  "num": 21,
  "cod": "M120340H6",
  "img": "imagens/2018/questao21.png",
  "alts": [
   "A",
   "B",
   "C",
   "D",
   "E"
  ],
  "texto": "21) (M120340H6) Observe o polinômio representado no quadro abaixo. p(x) = x. (x – 3). (x + 2) Quais são as raízes desse polinômio? A) – 6, – 1 e 1. B) – 3, 0 e 2. C) – 3 e 2. D) – 2 e 3. E) – 2, 0 e 3. BL01M12 8"
 },
 {
  "ano": "2018",
  "num": 22,
  "cod": "M120409H6",
  "img": "imagens/2018/questao22.png",
  "alts": [
   "A",
   "B",
   "C",
   "D",
   "E"
  ],
  "texto": "22) (M120409H6) Observe, no desenho abaixo, o esquema de um estábulo que foi construído para acomodar dez cavalos. 20 m 14 m Qual é a medida da área ocupada por esse estábulo? A) 960 m2 B) 280 m2 C) 140 m2 D) 68 m2 E) 34 m2"
 },
 {
  "ano": "2018",
  "num": 23,
  "cod": "M110763E4",
  "img": "imagens/2018/questao23.png",
  "alts": [
   "A",
   "B",
   "C",
   "D",
   "E"
  ],
  "texto": "23) (M110763E4) Observe a reta numérica desenhada abaixo. Ela está dividida em segmentos de mesma medida. P 2,30 2,37 O ponto P representa nessa reta o número A) 2,31. B) 2,32. C) 2,33. D) 2,41. E) 2,60."
 },
 {
  "ano": "2018",
  "num": 24,
  "cod": "M120137H6",
  "img": "imagens/2018/questao24.png",
  "alts": [
   "A",
   "B",
   "C",
   "D",
   "E"
  ],
  "texto": "24) (M120137H6) Um estudante de gastronomia está participando de um concurso culinário no qual deverá criar um prato. Para isso, ele dispõe de 3 tipos de massas, 4 tipos de molho e 6 tipos de carne. De quantas formas distintas ele poderá montar um prato utilizando uma massa, um molho e uma carne? A) 3 B) 6 C) 13 D) 25 E) 72 BL01M12 9"
 },
 {
  "ano": "2018",
  "num": 25,
  "cod": "M120361H6",
  "img": "imagens/2018/questao25.png",
  "alts": [
   "A",
   "B",
   "C",
   "D",
   "E"
  ],
  "texto": "25) (M120361H6) Observe, no plano cartesiano abaixo, as retas r, s e t e os pontos M, N, O, P e Q. y s t M r P N Q O x A solução do sistema de equações formado pelas equações das retas s e t está representado nesse plano cartesiano pelo ponto A) M. B) N. C) O. D) P. E) Q."
 },
 {
  "ano": "2018",
  "num": 26,
  "cod": "M120415H6",
  "img": "imagens/2018/questao26.png",
  "alts": [
   "A",
   "B",
   "C",
   "D",
   "E"
  ],
  "texto": "26) (M120415H6) Em um balão de propaganda cheio com gás hélio, foram fixadas duas cordas que estavam amarradas em veículos distintos, conforme representado no desenho abaixo. Dados: sen 60° ≅ 0,87 cos 60° = 0,5 tg 60° ≅ 1,73 60° 1m 6m De acordo com esse desenho, qual é a altura desse balão em relação ao solo? A) 6,22 m B) 7,90 m C) 9,38 m D) 11,38 m E) 13,00 m 10 BL01M12"
 },
 {
  "ano": "2018",
  "num": 40,
  "cod": "M110375E4",
  "img": "imagens/2018/questao40.png",
  "alts": [
   "A",
   "B",
   "C",
   "D",
   "E"
  ],
  "texto": "40) (M110375E4) Observe os triângulos abaixo. Quais desses triângulos são semelhantes? A) I, II e III. B) I, II e V. C) I e III. D) II e IV. E) III e V."
 },
 {
  "ano": "2018",
  "num": 41,
  "cod": "M120014ES",
  "img": "imagens/2018/questao41.png",
  "alts": [
   "A",
   "B",
   "C",
   "D",
   "E"
  ],
  "texto": "41) (M120014ES) Uma empresa de arquitetura paga o salário de seus funcionários de acordo com a função apresentada no quadro abaixo. y = 2 230 + 1 100x Nessa função, y representa o salário mensal pago pela empresa de arquitetura ao profissional e x é o número de projetos desse funcionário que foram aprovados no mês. Qual foi o salário de um profissional que teve 3 de seus projetos aprovados em um mês? A) R$ 2 230,00 B) R$ 3 300,00 C) R$ 3 330,00 D) R$ 5 530,00 E) R$ 9 990,00 BL02M12 18"
 },
 {
  "ano": "2018",
  "num": 42,
  "cod": "M100398H6",
  "img": "imagens/2018/questao42.png",
  "alts": [
   "A",
   "B",
   "C",
   "D",
   "E"
  ],
  "texto": "42) (M100398H6) Amanda comprou uma forma de bolo com formato de bloco retangular, cujas medidas internas estão representadas na figura abaixo. A capacidade máxima, em cm³, dessa forma é A) 220. B) 500. C) 600. D) 1 100. E) 3 000."
 },
 {
  "ano": "2018",
  "num": 43,
  "cod": "M120241G5",
  "img": "imagens/2018/questao43.png",
  "alts": [
   "A",
   "B",
   "C",
   "D",
   "E"
  ],
  "texto": "43) (M120241G5) Em um parque de diversões cobra-se R$ 12,00 de ingresso para entrada no parque mais um valor de R$ 1,50 cada vez que o brinquedo for utilizado, conforme representado na tabela abaixo. Quantidade de Preço a ser pago brinquedos utilizados (em reais) 0 12,00 1 13,50 2 15,00 3 16,50 ... ... 10 27,00 A função que melhor expressa a relação entre o valor total a ser pago (P) e o número de vezes (n) em que os brinquedos foram utilizados é A) P = 12,00n. B) P = 12,00n + 1,50. C) P = 12,00 + 1,50n. D) P = 1,50n. E) P = 13,50n."
 },
 {
  "ano": "2018",
  "num": 44,
  "cod": "M120898E4",
  "img": "imagens/2018/questao44.png",
  "alts": [
   "A",
   "B",
   "C",
   "D",
   "E"
  ],
  "texto": "44) (M120898E4) A reta s passa pelos pontos (4, 1) e (2, 3). Qual é a equação dessa reta s? A) y = – x + 5 B) y = – 2x + 2 C) y = 2x + 3 D) y = 4x + 1 E) y = 6x + 4 BL02M12 19"
 },
 {
  "ano": "2018",
  "num": 45,
  "cod": "M120442H6",
  "img": "imagens/2018/questao45.png",
  "alts": [
   "A",
   "B",
   "C",
   "D",
   "E"
  ],
  "texto": "45) (M120442H6) Uma lanchonete vende sucos em copos com capacidade para 500 mL pelo preço de R$ 5,00. Atendendo aos pedidos de clientes, essa lanchonete também passará a vender seus sucos em copos que comportam 200 mL a mais do que o modelo atual, e o preço desse novo copo de suco será proporcional ao preço do suco vendido no copo de 500 mL. De acordo com essas informações, por qual valor essa lanchonete deve vender esse novo copo de suco? A) R$ 2,00 B) R$ 3,57 C) R$ 5,00 D) R$ 6,25 E) R$ 7,00"
 },
 {
  "ano": "2018",
  "num": 46,
  "cod": "M100522E4",
  "img": "imagens/2018/questao46.png",
  "alts": [
   "A",
   "B",
   "C",
   "D",
   "E"
  ],
  "texto": "46) (M100522E4) Foi feita uma pesquisa em uma determinada empresa para encontrar um horário alternativo para a entrada dos funcionários. Cada um escolheu o horário que era mais conveniente para iniciar o trabalho e o resultado está representado na tabela abaixo. Horários de chegada Percentual de funcionários 7h 31% 8h 14% 9h 46% 10h 9% Qual dos gráficos abaixo apresenta as informações dessa tabela? A) Horários de Chegada B) Horários de Chegada 9% 9% 14% 14% 31% 7h 7h 8h 8h 46% 31% 9h 9h 10h 10h 46% C) Horários de Chegada D) Horários de Chegada 14% 9% 9% 7h 31% 7h 46% 8h 8h 9h 46% 9h 31% 10h 10h 14% E) Horários de Chegada 9% 14% 7h 46% 8h 9h 31% 10h 14% BL02M12 20"
 },
 {
  "ano": "2018",
  "num": 47,
  "cod": "M100098H6",
  "img": "imagens/2018/questao47.png",
  "alts": [
   "A",
   "B",
   "C",
   "D",
   "E"
  ],
  "texto": "47) (M100098H6) Observe abaixo o gráfico de uma função real definida no intervalo [− 5, 7]. Essa função é estritamente decrescente A) no intervalo [– 5, 2] e no intervalo [0, 3]. B) no intervalo [– 5, 0]. C) no intervalo [– 2, 0] e no intervalo [3, 5]. D) no intervalo [1, 4]. E) no intervalo [5, 7]."
 },
 {
  "ano": "2018",
  "num": 48,
  "cod": "M120410H6",
  "img": "imagens/2018/questao48.png",
  "alts": [
   "A",
   "B",
   "C",
   "D",
   "E"
  ],
  "texto": "48) (M120410H6) Um professor de Matemática dividiu os alunos de sua turma em 13 grupos diferentes para apresentarem um trabalho. Para determinar a ordem das apresentações dos grupos, ele colocou em uma urna 13 cartões idênticos, numerados de 1 a 13, que foram sorteados aleatoriamente. Qual é a probabilidade do primeiro cartão retirado da urna ser um número maior que 8? 1 A) 13 5 B) 13 6 C) 13 7 D) 13 8 E) 13"
 },
 {
  "ano": "2018",
  "num": 49,
  "cod": "M100078H6",
  "img": "imagens/2018/questao49.png",
  "alts": [
   "A",
   "B",
   "C",
   "D",
   "E"
  ],
  "texto": "49) (M100078H6) Observe o pentágono IJKLM representado no plano cartesiano abaixo. y I J 2 1 –2 –1 0 x 1 2 –1 M K –2 L De acordo com esse plano cartesiano, o ponto de coordenadas (– 2, – 1) é A) I. B) J. C) K. D) L. E) M. 21 BL02M12"
 },
 {
  "ano": "2018",
  "num": 50,
  "cod": "M120384H6",
  "img": "imagens/2018/questao50.png",
  "alts": [
   "A",
   "B",
   "C",
   "D",
   "E"
  ],
  "texto": "50) (M120384H6) Observe abaixo o esboço do gráfico de uma função polinomial do 1º grau f: IR → IR. y 4 3 2 1 –4 –3 –2 –1 0 1 2 3 4 x –1 –2 –3 –4 A representação algébrica dessa função é A) f(x) = x + 4. B) f(x) = x – 4. C) f(x) = – 4x. D) f(x) = – 4x + 1. E) f(x) = – 4x + 4."
 },
 {
  "ano": "2018",
  "num": 51,
  "cod": "M110030E4",
  "img": "imagens/2018/questao51.png",
  "alts": [
   "A",
   "B",
   "C",
   "D",
   "E"
  ],
  "texto": "51) (M110030E4) Marcos usou dois triângulos e dois trapézios idênticos aos das figuras I e II para construir o retângulo ABCD, conforme o desenho abaixo. Figura I Figura II KK RR Qual é a medida do perímetro do retângulo ABCD construído por Marcos? A) 30 cm B) 32 cm C) 44 cm D) 47 cm E) 56 cm"
 },
 {
  "ano": "2018",
  "num": 52,
  "cod": "M120890E4",
  "img": "imagens/2018/questao52.png",
  "alts": [
   "A",
   "B",
   "C",
   "D",
   "E"
  ],
  "texto": "52) (M120890E4) Observe o sistema de equações lineares abaixo. 2x + 3y + 4z = 58 *3x - 5y = 8 2y = 4 A solução desse sistema é o terno ordenado A) (2, 3, 0). B) (3, – 5, 2). C) (4, 0, 0). D) (6, 2, 10). E) (58, 8, 4). BL02M12 22"
 },
 {
  "ano": "2019",
  "num": 27,
  "cod": "M120701H6",
  "img": "imagens/2019/questao27.png",
  "alts": [
   "A",
   "B",
   "C",
   "D",
   "E"
  ],
  "texto": "27) (M120701H6) Observe os pontos P, Q, R, S e T representados no plano cartesiano abaixo. y 4 3 S R 2 1 –4 –3 –2 –1 0 1 2 3 4 x –1 T Q –2 P –3 –4 Em qual desses pontos a abscissa é – 3 e a ordenada é – 2? A) P. B) Q. C) R. D) S. E) T."
 },
 {
  "ano": "2019",
  "num": 28,
  "cod": "M110095H6",
  "img": "imagens/2019/questao28.png",
  "alts": [
   "A",
   "B",
   "C",
   "D",
   "E"
  ],
  "texto": "28) (M110095H6) Daniela foi contemplada em um programa de inclusão educacional, por meio do qual obteve um desconto de 60% nas mensalidades de um curso. A mensalidade integral desse curso é R$ 936,00. Dessa forma, qual será o valor da mensalidade paga por Daniela? A) R$ 374,40 B) R$ 561,60 C) R$ 624,00 D) R$ 876,00 E) R$ 935,40 BL02M12 14"
 },
 {
  "ano": "2019",
  "num": 29,
  "cod": "M120659H6",
  "img": "imagens/2019/questao29.png",
  "alts": [
   "A",
   "B",
   "C",
   "D",
   "E"
  ],
  "texto": "29) (M120659H6) Uma pizzaria proporciona um serviço em que o cliente pode montar a sua pizza. É possível escolher a massa e um ingrediente de cada um dos 3 grupos, conforme o cardápio representado abaixo. Tipo de Massa: Carne: Comum Calabresa Integral Carne seca Frango Pepperoni Opções: a Brócolis Monte su Ervilha Pizza Milho Ovo Palmito Presunto Queijos: Muçarela Parmesão Provolone Sônia planeja comprar uma pizza nessa pizzaria para lanchar com seus filhos. De quantas formas diferentes Sônia pode escolher a massa e os ingredientes para montar a sua pizza? A) 15 B) 72 C) 144 D) 752 E) 1 365"
 },
 {
  "ano": "2019",
  "num": 30,
  "cod": "M120247G5",
  "img": "imagens/2019/questao30.png",
  "alts": [
   "A",
   "B",
   "C",
   "D",
   "E"
  ],
  "texto": "30) (M120247G5) Um avião levanta voo na cidade de Vitória - ES com destino a São Paulo - SP. Durante os dez primeiros minutos de voo, sua velocidade aumenta até atingir 800 km/h. A partir daí, o piloto automático é acionado, e essa velocidade permanece constante até que, cinquenta minutos após a decolagem, o piloto é orientado pela torre de controle para reduzir a velocidade para 600 km/h. Três minutos após essa orientação, o avião atinge 600 km/h e permanece nessa velocidade por mais 17 minutos, até iniciar os procedimentos de pouso na cidade de São Paulo, onde sua velocidade diminui até o pouso. O gráfico que melhor representa a velocidade desse avião em função do tempo é A) V (km/h) B) V (km/h) 800 800 600 600 0 0 10 50 70 t (min.) 10 50 70 t (min.) C) V (km/h) D) V (km/h) 800 800 0 0 10 70 t (min.) 10 70 t (min.) E) V (km/h) 800 600 0 10 50 70 t (min.) BL02M12 15"
 },
 {
  "ano": "2019",
  "num": 31,
  "cod": "M120276H6",
  "img": "imagens/2019/questao31.png",
  "alts": [
   "A",
   "B",
   "C",
   "D",
   "E"
  ],
  "texto": "31) (M120276H6) Observe abaixo as duas retas r e s traçadas em um plano cartesiano em que os pontos H, I, J, K, L foram destacados. y s r H I J K L x A solução do sistema que envolve as equações das retas r e s é o ponto A) H. B) I. C) J. D) K. E) L."
 },
 {
  "ano": "2019",
  "num": 32,
  "cod": "M110364H6",
  "img": "imagens/2019/questao32.png",
  "alts": [
   "A",
   "B",
   "C",
   "D",
   "E"
  ],
  "texto": "32) (M110364H6) Existe uma unidade de medida de velocidade, denominada nó, que é utilizada em navegação marítima e aérea. A velocidade máxima do maior navio cargueiro do mundo é 25 nós, o que equivale a 46,3 km/h. Existem aviões comerciais que atingem a velocidade máxima de 500 nós. De acordo com essas informações, qual é a velocidade máxima, em km/h, que esses aviões comerciais atingem? A) 270 B) 479 C) 500 D) 521 E) 926"
 },
 {
  "ano": "2019",
  "num": 33,
  "cod": "M120392ES",
  "img": "imagens/2019/questao33.png",
  "alts": [
   "A",
   "B",
   "C",
   "D",
   "E"
  ],
  "texto": "33) (M120392ES) No desenho abaixo estão representados os triângulos I, II, III e IV e suas medidas em centímetros. 12 cm IV 20 cm 24 cm 12 cm 12 cm 16 cm 10 cm 10 m III 6m II I 8m 12 cm 20 cm O par de triângulos semelhantes nesse desenho é A) I e II. B) I e III. C) I e IV. D) II e IV. E) III e IV. 16 BL02M12"
 },
 {
  "ano": "2019",
  "num": 34,
  "cod": "M120460H6",
  "img": "imagens/2019/questao34.png",
  "alts": [
   "A",
   "B",
   "C",
   "D",
   "E"
  ],
  "texto": "34) (M120460H6) Observe abaixo um esboço do gráfico da função polinomial do 1º grau f : IR → IR. y 1 –2 –1 0 x 1 2 3 –1 –2 –3 –4 –5 A lei de formação dessa função f é A) y = – 4x – 4. B) y = – 4x + 1. C) y = – 4x + 4. D) y = 4x – 4. E) y = 4x + 1."
 },
 {
  "ano": "2019",
  "num": 35,
  "cod": "M120195H6",
  "img": "imagens/2019/questao35.png",
  "alts": [
   "A",
   "B",
   "C",
   "D",
   "E"
  ],
  "texto": "35) (M120195H6) Observe no desenho abaixo o projeto da quadra de basquete que será construída no condomínio em que Bruno mora. 30 metros 16 metros A medida da área dessa quadra de basquete, em metros quadrados, será A) 480. B) 240. C) 92. D) 46. E) 14."
 },
 {
  "ano": "2019",
  "num": 36,
  "cod": "M120187H6",
  "img": "imagens/2019/questao36.png",
  "alts": [
   "A",
   "B",
   "C",
   "D",
   "E"
  ],
  "texto": "36) (M120187H6) O custo diário de uma produção de potes de sorvete em uma empresa é dada pela função C(x) = x2 – 40x + 500, na qual, C(x) é o custo em reais e x é o número de unidades de potes de sorvete produzidos por essa empresa. Quantos potes de sorvetes devem ser produzidos diariamente por essa empresa para que o custo da produção seja mínimo? A) 10 B) 13 C) 20 D) 100 BL02M12 E) 500 17"
 },
 {
  "ano": "2019",
  "num": 37,
  "cod": "M120707H6",
  "img": "imagens/2019/questao37.png",
  "alts": [
   "A",
   "B",
   "C",
   "D",
   "E"
  ],
  "texto": "37) (M120707H6) A equipe organizadora de um processo seletivo submeteu os 30 candidatos inscritos nesse processo a dois tipos de avaliação: a análise de seus currículos e uma prova escrita. Em cada uma dessas avaliações, o candidato obteve entre 0 e 100 pontos. A tabela abaixo apresenta a distribuição desses candidatos em relação aos pontos obtidos por eles na análise de currículo e na prova escrita. DISTRIBUIÇÃO DOS CANDIDATOS INSCRITOS NO PROCESSO SELETIVO PONTOS ANÁLISE DE PROVA OBTIDOS CURRÍCULO ESCRITA 0 ˫ 20 2 4 20 ˫ 40 5 7 40 ˫ 60 9 12 60 ˫ 80 11 6 80 ˫ 100 3 1 O gráfico que corresponde às informações apresentadas nessa tabela é A) DISTRIBUIÇÃO DOS CANDIDATOS B) DISTRIBUIÇÃO DOS CANDIDATOS INSCRITOS NO PROCESSO SELETIVO INSCRITOS NO PROCESSO SELETIVO Pontos obtidos Pontos obtidos 80 100 80 100 60 80 60 80 40 60 40 60 PROVA PROVA 20 40 ESCRITA 20 40 ESCRITA 0 20 ANÁLISE 0 20 ANÁLISE DE CURRÍCULO DE CURRÍCULO 0 1 2 3 4 5 6 7 8 9 10111213 0 1 2 3 4 5 6 7 8 9 10111213 Quantidade de candidatos Quantidade de candidatos C) DISTRIBUIÇÃO DOS CANDIDATOS D) DISTRIBUIÇÃO DOS CANDIDATOS INSCRITOS NO PROCESSO SELETIVO INSCRITOS NO PROCESSO SELETIVO Pontos obtidos Pontos obtidos 80 100 80 100 60 80 60 80 40 60 40 60 PROVA PROVA 20 40 ESCRITA 20 40 ESCRITA 0 20 ANÁLISE 0 20 ANÁLISE DE CURRÍCULO DE CURRÍCULO 0 1 2 3 4 5 6 7 8 9 10111213 0 1 2 3 4 5 6 7 8 9 10111213 Quantidade de candidatos Quantidade de candidatos E) DISTRIBUIÇÃO DOS CANDIDATOS INSCRITOS NO PROCESSO SELETIVO Pontos obtidos 80 100 60 80 40 60 PROVA 20 40 ESCRITA 0 20 ANÁLISE DE CURRÍCULO 0 1 2 3 4 5 6 7 8 9 10111213 Quantidade de candidatos BL02M12 18"
 },
 {
  "ano": "2019",
  "num": 38,
  "cod": "M120889E4",
  "img": "imagens/2019/questao38.png",
  "alts": [
   "A",
   "B",
   "C",
   "D",
   "E"
  ],
  "texto": "38) (M120889E4) Observe o sistema de equações lineares abaixo. 2x + y + z = 8 *x + y + 4z = 15 3y + 2z = 9 A solução desse sistema é o terno ordenado A) (2, –1, – 19). B) (2, 1, 3). C) (8, – 22, – 57). D) (8, – 22, 9). E) (8, 15, 9)."
 },
 {
  "ano": "2019",
  "num": 39,
  "cod": "M120710H6",
  "img": "imagens/2019/questao39.png",
  "alts": [
   "A",
   "B",
   "C",
   "D",
   "E"
  ],
  "texto": "39) (M120710H6) Para evitar que os estudantes de uma escola atravessassem a rua de forma desordenada até o ponto de ônibus ou vice-versa, foi solicitada a demarcação de uma faixa de pedestre em frente a essa escola. A figura abaixo apresenta as localizações da escola e do ponto de ônibus, a faixa de pedestre que foi demarcada e algumas distâncias. Escola 14 ,0 m Ponto de ônibus 4√ 6 m Quantos metros, no mínimo, um estudante percorre ao atravessar essa faixa de pedestre para ir da escola até o ponto de ônibus? A) 10,0. B) 13,1. C) 14,0. D) 17,1. E) 23,6. BL02M12 19"
 },
 {
  "ano": "2019",
  "num": 40,
  "cod": "M120700H6",
  "img": "imagens/2019/questao40.png",
  "alts": [
   "A",
   "B",
   "C",
   "D",
   "E"
  ],
  "texto": "40) (M120700H6) Observe o sólido geométrico desenhado abaixo. Uma planificação da superfície desse sólido está representada em A) B) C) D) E)"
 },
 {
  "ano": "2019",
  "num": 41,
  "cod": "M110370H6",
  "img": "imagens/2019/questao41.png",
  "alts": [
   "A",
   "B",
   "C",
   "D",
   "E"
  ],
  "texto": "41) (M110370H6) Em março de 2017, Taís começou a trabalhar como manicure e comprou 8 vidros de esmalte. Após isso, a cada mês, ela comprou 2 vidros de esmalte a mais do que havia comprado no mês anterior. Em agosto de 2017, o preço de cada vidro de esmalte era R$ 3,75. A quantia gasta por Taís, em agosto de 2017, na compra desses vidros de esmalte foi A) R$ 37,50. Dado: B) R$ 45,00. an = a1 + (n – 1) . r C) R$ 52,50. D) R$ 67,50. E) R$ 75,00. BL01M12 20"
 },
 {
  "ano": "2019",
  "num": 42,
  "cod": "M120915E4",
  "img": "imagens/2019/questao42.png",
  "alts": [
   "A",
   "B",
   "C",
   "D",
   "E"
  ],
  "texto": "42) (M120915E4) O gráfico abaixo representa uma função quadrática no intervalo [– 4, 4]. Com base nesse gráfico, os zeros da função são A) – 4 e 4. B) – 4 e 6. C) – 2 e 2. D) 0 e 2. E) 4 e – 6."
 },
 {
  "ano": "2019",
  "num": 43,
  "cod": "M120900E4",
  "img": "imagens/2019/questao43.png",
  "alts": [
   "A",
   "B",
   "C",
   "D",
   "E"
  ],
  "texto": "43) (M120900E4) Uma indústria confeccionou um modelo de porta-óculos que possui o formato de prisma reto de base triangular regular, feito de papelão revestido de tecido, conforme representado no desenho abaixo. Dados: L2 3 Abase = 4 16,5 cm 3 ≅ 1,73 8 cm Quantos centímetros quadrados de papelão revestido de tecido são utilizados, no mínimo, para confeccionar cada um desses porta-óculos? A) 159,68 B) 396,00 C) 423,68 D) 451,36 BL01M12 E) 913,44 21"
 },
 {
  "ano": "2019",
  "num": 44,
  "cod": "M120447A8",
  "img": "imagens/2019/questao44.png",
  "alts": [
   "A",
   "B",
   "C",
   "D",
   "E"
  ],
  "texto": "44) (M120447A8) Dentro de uma sacola existem cinco bolas numeradas com 1, 2, 3, 4 e 5, cada bola com um número. Letícia retira uma bola da sacola, lê o número escrito nela e devolve a bola para a sacola. Em seguida, ela retira novamente uma bola da sacola, e lê o número escrito nela. Qual é a probabilidade de os dois números lidos por Letícia serem iguais? 1 A) 25 2 B) 25 1 C) 10 1 D) 2 1 E) 5"
 },
 {
  "ano": "2019",
  "num": 45,
  "cod": "M120184H6",
  "img": "imagens/2019/questao45.png",
  "alts": [
   "A",
   "B",
   "C",
   "D",
   "E"
  ],
  "texto": "45) (M120184H6) A reta k passa pelos pontos de coordenadas (0, 1) e (3, 2). Qual é a equação reduzida dessa reta? A) y = – 3x – 1 x B) y = + 1 3 C) y = x + 3 D) y = 3x + 1 E) y = 3x + 2"
 },
 {
  "ano": "2019",
  "num": 46,
  "cod": "M100112H6",
  "img": "imagens/2019/questao46.png",
  "alts": [
   "A",
   "B",
   "C",
   "D",
   "E"
  ],
  "texto": "46) (M100112H6) O gráfico abaixo apresenta a média das notas nas avaliações de cada bimestre dos estudantes de uma turma do primeiro ano do Ensino Médio nas disciplinas Matemática e Língua Portuguesa. Evolução das Médias Bimestrais 10 8,6 8,9 9 8 7,2 7,3 7,5 Médias das notas 7 6,1 5,9 6 5,4 5 Matemática 4 Língua Portuguesa 3 2 1 0 1º Bim 2º Bim 3º Bim 4º Bim Bimestres De acordo com os dados desse gráfico, os aumentos verificados nas médias das notas do segundo para o terceiro bimestre, nas disciplinas de Matemática e de Língua Portuguesa, foram, respectivamente, iguais a A) 0,7 e 1,3. B) 1,1 e 1,3. C) 1,2 e 1,4. D) 1,9 e 2,7. E) 2,1 e 3,0. BL01M12 22"
 },
 {
  "ano": "2019",
  "num": 47,
  "cod": "M110309H6",
  "img": "imagens/2019/questao47.png",
  "alts": [
   "A",
   "B",
   "C",
   "D",
   "E"
  ],
  "texto": "47) (M110309H6) O esboço do gráfico da função f: IR→IR, definida por f(x) = sen(x) é A) B) –3 –3 C) D) –3 –3 E) –3"
 },
 {
  "ano": "2019",
  "num": 48,
  "cod": "M120569H6",
  "img": "imagens/2019/questao48.png",
  "alts": [
   "A",
   "B",
   "C",
   "D",
   "E"
  ],
  "texto": "48) (M120569H6) Um polinômio P(x) de grau 3 tem como raízes os números reais – 1, 2 e – 3. O coeficiente do termo de maior grau desse polinômio é 1. A decomposição do polinômio P(x) é A) (x + 1) . (x – 2 ) . (x + 3). B) (x – 1) . (x + 2 ) . (x – 3). C) (x + 1) . (x + 2 ) . (x + 3). D) (x – 1) . (x – 2 ) . (x – 3). E) (x + 1) . (x + 2 ) . (x – 3)."
 },
 {
  "ano": "2019",
  "num": 49,
  "cod": "M110077H6",
  "img": "imagens/2019/questao49.png",
  "alts": [
   "A",
   "B",
   "C",
   "D",
   "E"
  ],
  "texto": "49) (M110077H6) A molécula de metano é composta por um átomo de carbono e átomos de hidrogênio. O número de ligações simples entre o átomo de carbono e os átomos de hidrogênio define uma geometria molecular na forma de um poliedro convexo formado por 4 faces triangulares e cujos vértices são compostos pelos átomos de hidrogênio. Qual é o número de átomos de hidrogênio existentes na molécula de metano? A) 12 B) 10 C) 8 D) 4 E) 2 BL01M12 23"
 },
 {
  "ano": "2019",
  "num": 50,
  "cod": "M120927E4",
  "img": "imagens/2019/questao50.png",
  "alts": [
   "A",
   "B",
   "C",
   "D",
   "E"
  ],
  "texto": "50) (M120927E4) O gráfico que representa a função y = 6x + 1 é A) y B) y 7 7 6 6 5 5 4 4 3 3 2 2 1 1 –2 –1 0 1 x –2 –1 0 1 x C) y D) y 7 1 6 –2 –1 0 1 x 5 –1 4 –2 3 –3 2 –4 1 –5 –6 –2 –1 0 1 x E) y 1 –2 –1 0 1 x –1 –2 –3 –4 –5 BL01M12 24"
 },
 {
  "ano": "2019",
  "num": 51,
  "cod": "M110764E4",
  "img": "imagens/2019/questao51.png",
  "alts": [
   "A",
   "B",
   "C",
   "D",
   "E"
  ],
  "texto": "51) (M110764E4) Caroline está completando a reta numérica representada abaixo, na qual as distâncias entre dois pontos consecutivos são todas iguais. R –32 –24 –8 0 8 Para completar essa reta numérica, qual número Caroline deve escrever no lugar da letra R? A) – 25 B) − 23 C) − 16 D) − 9 E) − 7"
 },
 {
  "ano": "2019",
  "num": 52,
  "cod": "M120325H6",
  "img": "imagens/2019/questao52.png",
  "alts": [
   "A",
   "B",
   "C",
   "D",
   "E"
  ],
  "texto": "52) (M120325H6) Os coeficientes da equação reduzida de uma reta r são ambos negativos. Qual das retas abaixo pode representar a reta r? A) y B) y r r x x C) y D) y r x x r E) y r x BL01M12 25"
 },
 {
  "ano": "2021",
  "num": 27,
  "cod": "M120072I7",
  "img": "imagens/2021/questao27.png",
  "alts": [
   "A",
   "B",
   "C",
   "D",
   "E"
  ],
  "texto": "27) (M120072I7) De acordo com os dados do Censo da Educação Superior de 2016, divulgados pelo Ministério da Educação (MEC), no Brasil existem mais de um milhão de matrículas presenciais na rede federal de educação superior. A tabela abaixo apresenta o percentual dessas matrículas em cada uma das cinco regiões brasileiras. Matrículas presenciais na rede federal de educação superior PERCENTUAL DE MATRÍCULA 35,0% 30,4% 29,8% 30,0% 25,0% 20,0% 17,2% 15,0% 12,6% 10,0% 10,0% 5,0% Centro-Oeste Nordeste Norte Sudeste Sul REGIÃO BRASILEIRA Disponível em: <http://portal.inep.gov.br/artigo/-/asset_publisher/B4AQV9zFY7Bv/content/mec-e-inep-divulgam-dados-do-censo-da-educacao- superior-2016/21206>. Acesso em: 26 out 2018. A tabela que corresponde aos dados apresentados nesse gráfico é A) Matrículas presenciais na B) Matrículas presenciais na rede federal de educação superior rede federal de educação superior Região Centro-Oeste 17,2% Região Centro-Oeste 10,0% Região Nordeste 30,4% Região Nordeste 29,8% Região Norte 12,6% Região Norte 12,6% Região Sudeste 29,8% Região Sudeste 30,4% Região Sul 10,0% Região Sul 17,2% C) Matrículas presenciais na D) Matrículas presenciais na rede federal de educação superior rede federal de educação superior Região Centro-Oeste 10,0% Região Centro-Oeste 30,4% Região Nordeste 30,4% Região Nordeste 10,0% Região Norte 12,6% Região Norte 12,6% Região Sudeste 29,8% Região Sudeste 29,8% Região Sul 17,2% Região Sul 17,2% E) Matrículas presenciais na rede federal de educação superior Região Centro-Oeste 10,0% Região Nordeste 12,6% Região Norte 30,4% Região Sudeste 29,8% Região Sul 17,2% BL01M12 15"
 },
 {
  "ano": "2021",
  "num": 28,
  "cod": "M110033E4",
  "img": "imagens/2021/questao28.png",
  "alts": [
   "A",
   "B",
   "C",
   "D",
   "E"
  ],
  "texto": "28) (M110033E4) O plano cartesiano abaixo representa parte do mapa de uma cidade em que os estabelecimentos estão associados a pontos desse plano. Qual estabelecimento dessa cidade está associado ao ponto de coordenadas (– 20, –10)? A) Cinema. B) Farmácia. C) Hospital. D) Igreja. E) Restaurante."
 },
 {
  "ano": "2021",
  "num": 29,
  "cod": "M120279G5",
  "img": "imagens/2021/questao29.png",
  "alts": [
   "A",
   "B",
   "C",
   "D",
   "E"
  ],
  "texto": "29) (M120279G5) Ao final de uma semana, a diferença entre o quadrado do tempo total gasto por José na fase de um jogo e o total desse tempo é de 156 horas. Quanto tempo, em horas, José gastou jogando essa fase do jogo? A) 12 B) 13 C) 24 D) 25 E) 26"
 },
 {
  "ano": "2021",
  "num": 30,
  "cod": "M120321H6",
  "img": "imagens/2021/questao30.png",
  "alts": [
   "A",
   "B",
   "C",
   "D",
   "E"
  ],
  "texto": "30) (M120321H6) Para uma exposição de lançamento de marcas, serão colados 2 adesivos com os nomes das empresas participantes em cada uma das faces de um poliedro convexo de 16 arestas e 10 vértices, feito de papelão. Quantos adesivos ao todo serão colados nesse poliedro de papelão? A) 52 B) 48 C) 44 D) 20 E) 16 BL01M12 16"
 },
 {
  "ano": "2021",
  "num": 31,
  "cod": "M120408H6",
  "img": "imagens/2021/questao31.png",
  "alts": [
   "A",
   "B",
   "C",
   "D",
   "E"
  ],
  "texto": "31) (M120408H6) Observe abaixo o gráfico de uma função f: [– 3, 7] → IR. Quais são os zeros dessa função? A) ̶ 5 e 4. B) ̶ 3, ̶ 2, 2, 6 e 7. C) – 3 e 0. D) ̶ 3 e 7. E) ̶ 2, 2 e 6."
 },
 {
  "ano": "2021",
  "num": 32,
  "cod": "M110137E4",
  "img": "imagens/2021/questao32.png",
  "alts": [
   "A",
   "B",
   "C",
   "D",
   "E"
  ],
  "texto": "32) (M110137E4) O desenho abaixo representa o terreno da chácara de Paula, que possui o formato de um paralelogramo. Parte do terreno dessa chácara foi utilizado para fazer um jardim e um pomar e, na parte retangular colorida de cinza, Paula pretende construir uma casa. 30 m 12 m Jardim Pomar 5m 8m O jardim e o pomar dessa chácara ocupam, ao todo, uma área de A) 360 m2. B) 204 m2. C) 156 m2. D) 84 m2. E) 55 m2. BL01M12 17"
 },
 {
  "ano": "2021",
  "num": 33,
  "cod": "M120403H6",
  "img": "imagens/2021/questao33.png",
  "alts": [
   "A",
   "B",
   "C",
   "D",
   "E"
  ],
  "texto": "33) (M120403H6) Uma empresa de construção aluga caçambas para entulhos, por dia, cobrando uma taxa fixa, referente ao deslocamento, acrescida do valor relativo às diárias da caçamba, conforme representado na tabela abaixo. Taxa fixa Diárias Total Dias (em R$) (em R$) (em R$) 1 20 30 50 2 20 60 80 3 20 90 110 4 20 120 140 5 20 150 170 A representação algébrica da relação que permite calcular o valor V a ser pago pelo aluguel de uma caçamba em função da quantidade x de dias em que ela permaneceu alugada é A) T = 30 . x + 20. B) T = 20 . x + 30. C) T = 50 . x + 30. D) T = 20 . x. E) T = 30 . x."
 },
 {
  "ano": "2021",
  "num": 34,
  "cod": "M120190G5",
  "img": "imagens/2021/questao34.png",
  "alts": [
   "A",
   "B",
   "C",
   "D",
   "E"
  ],
  "texto": "34) (M120190G5) Um professor de Matemática desenhou vários triângulos em uma malha quadriculada. Qual par de triângulos desenhados pelo professor representa triângulos semelhantes? A) B) C) D) E) BL01M12 18"
 },
 {
  "ano": "2021",
  "num": 35,
  "cod": "M100063E4",
  "img": "imagens/2021/questao35.png",
  "alts": [
   "A",
   "B",
   "C",
   "D",
   "E"
  ],
  "texto": "35) (M100063E4) Um polinômio é tal que suas raízes são – 5, – 2 e 3. Uma possível forma fatorada desse polinômio é A) (x + 5)·(x + 2)·(x + 3) B) (x + 5)·(x – 2)·(x – 3) C) (x + 5)·(x + 2)·(x – 3) D) (x – 5)·(x – 2)·(x + 3) E) (x – 5)·(x – 2)·(x – 3)"
 },
 {
  "ano": "2021",
  "num": 36,
  "cod": "M120076I7",
  "img": "imagens/2021/questao36.png",
  "alts": [
   "A",
   "B",
   "C",
   "D",
   "E"
  ],
  "texto": "36) (M120076I7) Uma escola de esportes comprou 30 bolas de basquete, 10 de vôlei e 20 de futebol para presentear seus alunos. Cada uma dessas bolas foi embrulhada em um pacote que não permitia sua identificação. Afonso, um dos alunos dessa escola, será o primeiro a escolher, aleatoriamente, um desses pacotes para ganhar de presente. Qual é a probabilidade de Afonso ganhar uma bola de vôlei? 1 . A) 60 10 . B) 60 10 . C) 50 50 . D) 60 60 . E) 10"
 },
 {
  "ano": "2021",
  "num": 37,
  "cod": "M110249H6",
  "img": "imagens/2021/questao37.png",
  "alts": [
   "A",
   "B",
   "C",
   "D",
   "E"
  ],
  "texto": "37) (M110249H6) Carolina participou de um processo seletivo para a obtenção de bolsas de estudo em um colégio particular de sua cidade. Para isso, ela fez uma prova que era composta de 90 questões e, ao verificar o gabarito, constatou que acertou 72 questões. Qual foi o percentual de questões dessa prova que Carolina acertou? A) 20% B) 65% C) 72% D) 80% E) 82%"
 },
 {
  "ano": "2021",
  "num": 38,
  "cod": "M110032I7",
  "img": "imagens/2021/questao38.png",
  "alts": [
   "A",
   "B",
   "C",
   "D",
   "E"
  ],
  "texto": "38) (M110032I7) Juliano fez uma casinha de madeira para o seu cachorro. Algumas medidas internas da parede traseira dessa casinha estão indicadas na figura abaixo. Dados: 39 cm sen 40° ≅ 0,64 cos 40° ≅ 0,77 40º tg 40° ≅ 0,84 Altura interna da casinha 40 cm Qual é a medida da altura interna dessa casinha? A) 64,96 cm. B) 70,03 cm. C) 72,76 cm. D) 78,36 cm. BL01M12 E) 79,00 cm. 19"
 },
 {
  "ano": "2021",
  "num": 39,
  "cod": "M120693H6",
  "img": "imagens/2021/questao39.png",
  "alts": [
   "A",
   "B",
   "C",
   "D",
   "E"
  ],
  "texto": "39) (M120693H6) O gráfico abaixo representa uma função f: IR → IR+* tal que sua lei de formação é do tipo f(x) = px + q. y 5 2 –2 0 x A lei de formação dessa função f é A) f(x) = 2x. B) f(x) = 2x + 1. 1 x C) f(x) = ` j . 2 1 x D) f(x) = ` j + 1. 2 1 x E) f(x) = ` j + 6. 2 BL01M12 20"
 },
 {
  "ano": "2021",
  "num": 40,
  "cod": "M110236H6",
  "img": "imagens/2021/questao40.png",
  "alts": [
   "A",
   "B",
   "C",
   "D",
   "E"
  ],
  "texto": "40) (M110236H6) Dentre os anos de 2000 e 2012, a exportação de uma fruta aumentou um total de 5 000 toneladas a cada ano. No ano de 2010, a exportação dessa fruta foi de 103 000 toneladas. Quantas toneladas dessa fruta foram exportadas no ano 2000? A) 58 000 Dado: an = a1 + (n –1 ) . r B) 53 000 C) 9 800 D) 7 923 E) 5 300"
 },
 {
  "ano": "2021",
  "num": 41,
  "cod": "M120440A9",
  "img": "imagens/2021/questao41.png",
  "alts": [
   "A",
   "B",
   "C",
   "D",
   "E"
  ],
  "texto": "41) (M120440A9) Observe as duas retas traçadas no plano cartesiano abaixo. y r: y = – 2x + 6 s: y = 3x + 1 L K M P Q 0 x y = - 2x + 6 A solução do sistema ) é dada pelo ponto y = 3x + 1 A) K. B) L. C) M. D) P. E) Q."
 },
 {
  "ano": "2021",
  "num": 42,
  "cod": "M100273E4",
  "img": "imagens/2021/questao42.png",
  "alts": [
   "A",
   "B",
   "C",
   "D",
   "E"
  ],
  "texto": "42) (M100273E4) Observe a reta numérica abaixo. Essa reta está dividida em segmentos de mesma medida. P 0 10 Nessa reta numérica, o ponto P representa o número A) 6. B) 3. C) 2. D) – 3. E) – 6. BL02M12 21"
 },
 {
  "ano": "2021",
  "num": 43,
  "cod": "M120180I7",
  "img": "imagens/2021/questao43.png",
  "alts": [
   "A",
   "B",
   "C",
   "D",
   "E"
  ],
  "texto": "43) (M120180I7) Considere uma reta r que passa pelos pontos de coordenadas (– 12, 10) e (12, – 5). A equação geral da reta r está representada em A) – 24x – 15y + 60 = 0. B) – 12x + 10y – 7 = 0. C) 15x + 24y – 60 = 0. D) 17x + 22y – 60 = 0. E) 22x + 17y – 94 = 0."
 },
 {
  "ano": "2021",
  "num": 44,
  "cod": "M110097E4",
  "img": "imagens/2021/questao44.png",
  "alts": [
   "A",
   "B",
   "C",
   "D",
   "E"
  ],
  "texto": "44) (M110097E4) Paulo é dono de uma sorveteria e fez uma análise dos lucros dessa sorveteria no decorrer de um ano. Ele observou que no mês de janeiro (t=1), o lucro foi de 10 mil reais e continuou crescendo até o final do primeiro trimestre. No segundo trimestre, as vendas diminuíram e o lucro foi decrescendo até ficar nulo, e assim permaneceu até o final do terceiro trimestre do ano. Já no último trimestre, Paulo observou que o lucro voltou a crescer até atingir, no mês de dezembro, um lucro igual ao de janeiro. Qual é o gráfico que melhor representa o lucro dessa sorveteria em função dos meses do ano analisado por Paulo? A) B) C) D) E) BL02M12 22"
 },
 {
  "ano": "2021",
  "num": 45,
  "cod": "M110359H6",
  "img": "imagens/2021/questao45.png",
  "alts": [
   "A",
   "B",
   "C",
   "D",
   "E"
  ],
  "texto": "45) (M110359H6) Para comemorar o aniversário de uma cidade, foi promovida uma prova de corrida de rua em que os atletas participantes deveriam percorrer três voltas no circuito que está representado pelo contorno da figura abaixo. Partida - Chegada 1,5 km 0,4 km 0,7 km 0,6 km 0,3 km 0,9 km Quantos quilômetros, no mínimo, percorreu um atleta que completou essa prova? A) 2,61. B) 3,15. C) 6,60. D) 12,30. E) 13,20."
 },
 {
  "ano": "2021",
  "num": 46,
  "cod": "M120254G5",
  "img": "imagens/2021/questao46.png",
  "alts": [
   "A",
   "B",
   "C",
   "D",
   "E"
  ],
  "texto": "46) (M120254G5) Qual é o gráfico que melhor representa a função trigonométrica f(x) = 3 cos x ? 2 A) B) 4 1,5 5 –1,5 –3 –3 C) D) 1,5 –1,5 –3 E) 1,5 1,5 –3 BL02M12 23"
 },
 {
  "ano": "2021",
  "num": 47,
  "cod": "M120205H6",
  "img": "imagens/2021/questao47.png",
  "alts": [
   "A",
   "B",
   "C",
   "D",
   "E"
  ],
  "texto": "47) (M120205H6) Em uma lanchonete, os sanduíches vendidos são montados a partir das escolhas do próprio cliente. Para isso, essa lanchonete disponibiliza cinco variedades de pães, quatros tipos de carnes e cinco opções de saladas. De quantas maneiras diferentes um cliente pode montar um sanduíche nessa lanchonete escolhendo uma variedade de pão, uma de carne e uma de salada? A) 14 B) 42 C) 100 D) 264 E) 364"
 },
 {
  "ano": "2021",
  "num": 48,
  "cod": "M110004I7",
  "img": "imagens/2021/questao48.png",
  "alts": [
   "A",
   "B",
   "C",
   "D",
   "E"
  ],
  "texto": "48) (M110004I7) Luan trabalha com manutenção de lavadoras de roupas. Ele cobra, pelo seu serviço, uma taxa fixa de R$ 30,00, referente ao deslocamento, acrescida de R$ 15,00 por hora que trabalha. Em um determinado dia, Luan se deslocou para dois domicílios diferentes e fez a manutenção de uma lavadora de roupas em cada um deles, levando exatamente o mesmo tempo para realizar a manutenção em cada lavadora. Ao final do dia, Luan recebeu R$ 210,00 por esses dois serviços realizados. Quantas horas esse técnico levou para fazer a manutenção de cada uma dessas lavadoras de roupas? A) 5. B) 6. C) 10. D) 12. E) 14."
 },
 {
  "ano": "2021",
  "num": 49,
  "cod": "M110351H6",
  "img": "imagens/2021/questao49.png",
  "alts": [
   "A",
   "B",
   "C",
   "D",
   "E"
  ],
  "texto": "49) (M110351H6) Observe o sólido geométrico abaixo. Uma planificação desse sólido está representada em A) B) C) D) E) BL02M12 24"
 },
 {
  "ano": "2021",
  "num": 50,
  "cod": "M110255H6",
  "img": "imagens/2021/questao50.png",
  "alts": [
   "A",
   "B",
   "C",
   "D",
   "E"
  ],
  "texto": "50) (M110255H6) O Cobalto-60 é um elemento químico de transição usado como fonte de radiação gama em radioterapia e esterilização de alimentos. Esse elemento desintegra-se com o tempo e a relação que t fornece a massa de Cobalto-60 em função do tempo é M^th = M 0 $ ` 1 j5 , em que M0 é a massa inicial de 2 Cobalto-60 e t é o tempo, em anos. A massa de Cobalto-60, após 20 anos, é dada pela expressão M0 . A) 25 M0 . B) 24 M0 . C) 2 D) M0. E) 2M0."
 },
 {
  "ano": "2021",
  "num": 51,
  "cod": "M100053I7",
  "img": "imagens/2021/questao51.png",
  "alts": [
   "A",
   "B",
   "C",
   "D",
   "E"
  ],
  "texto": "51) (M100053I7) O pr opr iet ár io de um post o de combust íveis desej a compl et ar os t anques de ar mazenament o de cada tipo de combustível. Cada um desses tanques tem capacidade total de 5 000 litros e, antes de completá-los, o proprietário fez um levantamento das quantidades de combustível que havia em cada tanque. Esses dados estão apresentados na tabela abaixo. Estoque de combustível Quantidade Tanque de armazenamento (em litros) Diesel 3 283 Etanol 1 673 Gasolina 1 872 Gasolina aditivada 3 374 De acordo com essa tabela, para estar completo, quantos litros de combustível deverão ser colocados no tanque que precisava da maior quantidade de combustível? A) 1 626. B) 1 673. C) 3 128. D) 3 327. E) 9 798."
 },
 {
  "ano": "2021",
  "num": 52,
  "cod": "M120082I7",
  "img": "imagens/2021/questao52.png",
  "alts": [
   "A",
   "B",
   "C",
   "D",
   "E"
  ],
  "texto": "52) (M120082I7) Vinícius é artesão e produz vasos de argila. Para produzir 5 vasos de mesmo tamanho e modelo, ele utiliza 2 quilogramas de um determinado tipo de argila cujo quilograma custa R$ 8,00. Vinícius recebeu uma encomenda de 60 desses vasos e comprou toda a quantidade de argila necessária para produzi-los. Qual foi o custo total da argila comprada por Vinícius para produzir essa encomenda? A) R$ 96,00. B) R$ 176,00. C) R$ 192,00. D) R$ 240,00. E) R$ 1 200,00. BL02M12 25"
 },
 {
  "ano": "2022",
  "num": 27,
  "cod": "M121383H6",
  "img": "imagens/2022/questao27.png",
  "alts": [
   "A",
   "B",
   "C",
   "D",
   "E"
  ],
  "texto": "27) (M121383H6) Observe os pontos P, Q, R, S e T na reta numérica abaixo, que está dividida em segmentos de mesma medida. P Q R S T 2 2 5 5 Qual é o ponto que representa o número - 4 nessa reta? 5 A) P. B) Q. C) R. D) S. E) T."
 },
 {
  "ano": "2022",
  "num": 28,
  "cod": "M120034I7",
  "img": "imagens/2022/questao28.png",
  "alts": [
   "A",
   "B",
   "C",
   "D",
   "E"
  ],
  "texto": "28) (M120034I7) Observe, no plano cartesiano abaixo, a representação geométrica de um sistema formado pelas equações das retas s e t, e alguns pontos destacados. y 6 M 5 4 3 2 1 O N –6 –5 –4 –3 –2 –1 0 1 2 3 4 5 6 x –1 –2 P –3 Q –4 t –5 –6 s Qual desses pontos é solução desse sistema? A) M. B) N. C) O. D) P. E) Q. BL01M12 15"
 },
 {
  "ano": "2022",
  "num": 29,
  "cod": "M100272I7",
  "img": "imagens/2022/questao29.png",
  "alts": [
   "A",
   "B",
   "C",
   "D",
   "E"
  ],
  "texto": "29) (M100272I7) Matilde comprou algumas barras de chocolate em um supermercado. A quantidade de barras de chocolate compradas por ela equivalia, numericamente, ao preço unitário de cada barra adicionado a 6 unidades. Ao todo, Matilde gastou R$ 16,00 com a compra dessas barras de chocolate. Qual foi a quantidade de barras de chocolate que Matilde comprou nesse supermercado? A) 2. B) 7. C) 8. D) 11. E) 14."
 },
 {
  "ano": "2022",
  "num": 30,
  "cod": "M120097I7",
  "img": "imagens/2022/questao30.png",
  "alts": [
   "A",
   "B",
   "C",
   "D",
   "E"
  ],
  "texto": "30) (M120097I7) Juliana comprou ladrilhos, que possuem o formato de um trapézio, para revestir parte da parede do seu banheiro. Na figura abaixo está representado um desses ladrilhos com algumas medidas indicadas. 10 cm 8,5 cm 20 cm Qual é a medida da área, em centímetros quadrados, ocupada por um desses ladrilhos na parede do banheiro de Juliana? A) 38,5 cm2. B) 127,5 cm2. C) 170,0 cm2. D) 255,0 cm2. E) 1 700,0 cm2. BL01M12 16"
 },
 {
  "ano": "2022",
  "num": 31,
  "cod": "M120152I7",
  "img": "imagens/2022/questao31.png",
  "alts": [
   "A",
   "B",
   "C",
   "D",
   "E"
  ],
  "texto": "31) (M120152I7) Considere uma função polinomial do 1º grau f: IR → IR cujo coeficiente linear é – 4 e o coeficiente angular é 5. O gráfico dessa função f está representado em A) y B) y 5 5 4 4 3 3 2 2 1 1 – 5 – 4 – 3 – 2 – 1 0 –5 1 5 x 4 2 3 4 –5 –4 –3 –2 –1 0 1 2 3 4 5 x –1 –1 –2 –2 –3 –3 –4 –4 –5 –5 C) y D) y 5 5 4 4 3 3 2 2 1 1 –5 –4 –3 –2 –1 0 5 x –5 –4 –3 –2 –1 0 5 x 4 – 5 1 2 3 4 1 2 3 4 –1 –1 –2 –2 –3 –3 –4 –4 –5 –5 E) y 5 4 3 2 1 4 – 5 –5 –4 –3 –2 –1 0 1 2 3 4 5 x –1 –2 –3 –4 –5 BL01M12 17"
 },
 {
  "ano": "2022",
  "num": 32,
  "cod": "M120164I7",
  "img": "imagens/2022/questao32.png",
  "alts": [
   "A",
   "B",
   "C",
   "D",
   "E"
  ],
  "texto": "32) (M120164I7) Considere os pontos R, S, T, U e V, representados no plano cartesiano abaixo. y S 8 7 6 5 T 4 R 3 2 1 –8 –7 –6 –5 –4 –3 –2 –1 0 1 2 3 4 5 6 7 8 x –1 –2 –3 –4 V –5 –6 –7 –8 U Qual desses pontos possui abscissa 8 e ordenada – 4? A) R. B) S. C) T. D) U. E) V."
 },
 {
  "ano": "2022",
  "num": 33,
  "cod": "M120085I7",
  "img": "imagens/2022/questao33.png",
  "alts": [
   "A",
   "B",
   "C",
   "D",
   "E"
  ],
  "texto": "33) (M120085I7) Observe o sistema de equações lineares apresentado abaixo. 2x + y - z = - 1 *- 2x + 2y + z = - 5 x+z = 2 O terno (x, y, z), que é solução desse sistema linear, é A) (− 9, 4, − 3 ). B) (− 1, − 5, 2). C) (1, − 2, 1). D) (1, 3, 1). E) (4, − 2, 7). BL01M12 18"
 },
 {
  "ano": "2022",
  "num": 34,
  "cod": "M121387H6",
  "img": "imagens/2022/questao34.png",
  "alts": [
   "A",
   "B",
   "C",
   "D",
   "E"
  ],
  "texto": "34) (M121387H6) Uma empresa irá presentear seus funcionários no final do ano. Para presentear esses funcionários, compraram 20 livros, 30 canecas, 18 garrafas térmicas e 35 estojos de canetas. Para serem imparciais na distribuição dos presentes, a empresa preparou uma urna contendo uma quantidade de cartões igual à quantidade de presentes a serem distribuídos, cada um deles indicando um prêmio. Cada funcionário irá retirar, aleatoriamente, um cartão dessa urna, e esse cartão irá indicar qual é o presente que esse funcionário irá receber. Luciana será a primeira a retirar um cartão dessa urna e deseja ganhar uma garrafa térmica. Qual é a probabilidade de Luciana ganhar a garrafa térmica? 1 A) 103 . 18 B) 103 . 18 C) 85 . 1 D) 4 . 103 E) 18 . BL01M12 19"
 },
 {
  "ano": "2022",
  "num": 35,
  "cod": "M120393H6",
  "img": "imagens/2022/questao35.png",
  "alts": [
   "A",
   "B",
   "C",
   "D",
   "E"
  ],
  "texto": "cos^ x h 35) (M120393H6) Um esboço do gráfico da função f:IR→IR, tal que f (x) = é 2 1 2 A) 1 2 B) C) 1 2 D) 1 2 E) BL01M12 20"
 },
 {
  "ano": "2022",
  "num": 36,
  "cod": "M121382H6",
  "img": "imagens/2022/questao36.png",
  "alts": [
   "A",
   "B",
   "C",
   "D",
   "E"
  ],
  "texto": "36) (M121382H6) Considere as equações I, II, III, IV e V, apresentadas no quadro abaixo. I II III IV V y - x = 14 ^ x - 9h2 ^y + 1h2 y = x 2 - 16 x2 y 2 ^ x - 2h2 + ^y + 3h2 = 16 - =1 + =1 8 8 5 3 Qual dessas equações representa uma circunferência? A) I. B) II. C) III. D) IV. E) V."
 },
 {
  "ano": "2022",
  "num": 37,
  "cod": "M120583E4",
  "img": "imagens/2022/questao37.png",
  "alts": [
   "A",
   "B",
   "C",
   "D",
   "E"
  ],
  "texto": "37) (M120583E4) Juliano é responsável pela equipe de manutenção de uma ferrovia. No primeiro dia de uma inspeção, sua equipe revisou 40% da extensão total dessa ferrovia e, no segundo dia, foram revisados os 120 quilômetros restantes. A extensão total dessa ferrovia, em quilômetros, é A) 300. B) 200. C) 192. D) 168. E) 160. BL01M12 21"
 },
 {
  "ano": "2022",
  "num": 38,
  "cod": "M121388H6",
  "img": "imagens/2022/questao38.png",
  "alts": [
   "A",
   "B",
   "C",
   "D",
   "E"
  ],
  "texto": "38) (M121388H6) O diretor de uma escola organizou uma tabela com as quantidades de meninas e de meninos que estudam em cada ano escolar do Ensino Médio dessa escola. A tabela elaborada por esse diretor está representada abaixo. Estudantes no Ensino Médio da escola Quantidade de estudantes Ano escolar Meninos Meninas 1º 36 38 2º 33 34 3º 32 35 Qual gráfico representa a relação entre os dados dessa tabela elaborada pelo diretor? A) Estudantes no Ensino Médio da escola B) Estudantes no Ensino Médio da escola 38 38 Quantidade de estudantes Quantidade de estudantes 40 40 35 36 36 34 33 35 34 33 32 32 30 30 Meninos Meninos 20 20 Meninas Meninas 10 10 0 0 1º 2º 3º 1º 2º 3º Ano escolar Ano escolar C) Estudantes no Ensino Médio da escola D) Estudantes no Ensino Médio da escola 38 38 Quantidade de estudantes Quantidade de estudantes 40 40 36 35 36 35 34 33 33 34 32 32 30 30 Meninos Meninos 20 20 Meninas Meninas 10 10 0 0 1º 2º 3º 1º 2º 3º Ano escolar Ano escolar E) Estudantes no Ensino Médio da escola 38 Quantidade de estudantes 40 36 35 33 34 32 30 Meninos 20 Meninas 10 0 1º 2º 3º Ano escolar BL01M12 22"
 },
 {
  "ano": "2022",
  "num": 39,
  "cod": "M120776I7",
  "img": "imagens/2022/questao39.png",
  "alts": [
   "A",
   "B",
   "C",
   "D",
   "E"
  ],
  "texto": "39) (M120776I7) Em uma pesquisa, verificou-se que determinado produto eletrônico sofreu desvalorização com o tempo, de maneira que seu valor V, em reais, t anos após o seu lançamento, pode ser determinado t pela função V (t) = 2500 $ ` 8 j2 . Gustavo comprou uma unidade desse produto eletrônico no ano de seu 10 lançamento e decidiu revendê-lo após 4 anos de uso. De acordo com essa função, qual era o valor, em reais, desse produto eletrônico comprado por Gustavo quando decidiu revendê-lo? A) R$ 1 024,00. B) R$ 1 600,00. C) R$ 2 000,00. D) R$ 2 500,00. E) R$ 4 000,00. BL01M12 23"
 },
 {
  "ano": "2022",
  "num": 40,
  "cod": "M120177I7",
  "img": "imagens/2022/questao40.png",
  "alts": [
   "A",
   "B",
   "C",
   "D",
   "E"
  ],
  "texto": "40) (M120177I7) Considere a função f: [– 4, 4] → IR, cujo gráfico está representado abaixo. y 5 4 3 2 1 –4 –3 –2 –1 0 1 2 3 4 x –1 –2 –3 –4 –5 Essa função f é estritamente crescente no intervalo A) [– 5, 5]. B) [– 4, 0]. C) [0, 4]. D) [0, 5]. E) [2, 4]."
 },
 {
  "ano": "2022",
  "num": 41,
  "cod": "M110236I7",
  "img": "imagens/2022/questao41.png",
  "alts": [
   "A",
   "B",
   "C",
   "D",
   "E"
  ],
  "texto": "41) (M110236I7) Os operários de uma construção irão instalar uma tábua entre dois patamares para a utilizarem como rampa de transporte de materiais. No desenho abaixo, está representada a distância entre esses patamares, bem como a disposição e a inclinação com que essa tábua será instalada. Dados: sen 15° ≅ 0,26 cos 15° ≅ 0,97 Táb ua tg 15° ≅ 0,27 15° 4,0 m De acordo com essas informações, aproximadamente, qual deverá ser a extensão, em metros, dessa tábua? A) 3,03 m. B) 3,88 m. C) 4,12 m. D) 14,81 m. E) 15,38 m. BL02M12 24"
 },
 {
  "ano": "2022",
  "num": 42,
  "cod": "M121385H6",
  "img": "imagens/2022/questao42.png",
  "alts": [
   "A",
   "B",
   "C",
   "D",
   "E"
  ],
  "texto": "42) (M121385H6) Considere o polinômio p(x), apresentado em sua forma fatorada no quadro abaixo. p(x) = (x + 1) · (x – 4) · (x + 6) Quais são as raízes desse polinômio? A) – 6, – 4 e – 1. B) – 6, – 1 e 4. C) – 4, 1 e 6. D) – 6, 1 e 4. E) 1, 4 e 6."
 },
 {
  "ano": "2022",
  "num": 43,
  "cod": "M120873I7",
  "img": "imagens/2022/questao43.png",
  "alts": [
   "A",
   "B",
   "C",
   "D",
   "E"
  ],
  "texto": "43) (M120873I7) Saulo está construindo uma casinha de brinquedo para as suas filhas. As paredes dessa casinha formam a superfície lateral de um prisma reto de base regular. Antes de instalar o telhado nessa casinha, Saulo irá pintar de rosa todas as suas paredes externas. Observe na figura abaixo o formato e algumas medidas das paredes externas que formam essa casinha. 1,8 m 1,0 m Qual é a medida da área total, em metros quadrados, das paredes dessa casinha que Saulo irá pintar de rosa? A) 1,8 m². B) 2,8 m². C) 10,8 m². D) 16,8 m². E) 33,6 m²."
 },
 {
  "ano": "2022",
  "num": 44,
  "cod": "M121384H6",
  "img": "imagens/2022/questao44.png",
  "alts": [
   "A",
   "B",
   "C",
   "D",
   "E"
  ],
  "texto": "44) (M121384H6) Mariana trabalha de casa por meio da internet. No início do expediente, ela baixa um arquivo que contém o que ela precisa para trabalhar durante o dia. Com seu provedor de internet, ela consegue baixar esse arquivo, utilizando uma velocidade de transferência de 6 Mbps, em 20 minutos. Mariana irá trocar o provedor de sua internet por outro, que oferece uma velocidade de transferência de 24 Mbps. Em quantos minutos Mariana passará a baixar esse arquivo, depois da troca do provedor de sua internet? A) 2 minutos. B) 5 minutos. C) 15 minutos. D) 20 minutos. E) 80 minutos."
 },
 {
  "ano": "2022",
  "num": 45,
  "cod": "M120360H6",
  "img": "imagens/2022/questao45.png",
  "alts": [
   "A",
   "B",
   "C",
   "D",
   "E"
  ],
  "texto": "45) (M120360H6) A equação da reta que passa por P(– 5, 4) e corta o eixo das abscissas no ponto (5, 0) é A) – 5x + y = –29. B) – 5x + y = 29. C) – 5x + 4y = 5. D) 2x + 5y = – 10. E) 2x + 5y = 10. BL02M12 25"
 },
 {
  "ano": "2022",
  "num": 46,
  "cod": "M120786H6",
  "img": "imagens/2022/questao46.png",
  "alts": [
   "A",
   "B",
   "C",
   "D",
   "E"
  ],
  "texto": "46) (M120786H6) Considere a função exponencial f: IR → IR definida por f(x) = ax + b, em que a e b são constantes reais, a > 0 e a ≠ 1, cujo gráfico está representado abaixo. y 2 1 –2 –1 0 1 2 3 x –1 –2 –3 A lei de formação dessa função f é A) f(x) = 3x – 2. B) f(x) = 3x – 3. 1 x C) f(x) = ` j – 3. 2 1 x D) f(x) = ` j – 2. 3 1 x E) f(x) = ` j – 3. 3"
 },
 {
  "ano": "2022",
  "num": 47,
  "cod": "M100229H6",
  "img": "imagens/2022/questao47.png",
  "alts": [
   "A",
   "B",
   "C",
   "D",
   "E"
  ],
  "texto": "47) (M100229H6) Observe, na tabela abaixo, o número de unidades vendidas dos 5 modelos de automóveis mais comercializados no Brasil nos primeiros seis meses do ano de 2015. Modelos mais vendidos no 1º semestre de 2015 MODELO JAN FEV MAR ABR MAI JUN 1 13 462 6 885 9 548 8 783 8 212 8 871 2 14 432 9 181 9 232 8 841 10 469 10 582 3 8 962 6 492 9 100 8 753 8 848 9 165 4 11 202 8 715 9 946 8 598 7 354 8 679 5 8 229 6 419 8 151 7 845 8 348 6 977 De acordo com essa tabela, quantos automóveis desses 5 modelos foram vendidos no mês de maio de 2015? A) 8 212 B) 8 348 C) 10 469 D) 43 231 E) 45 969 BL02M12 26"
 },
 {
  "ano": "2022",
  "num": 48,
  "cod": "M120029I7",
  "img": "imagens/2022/questao48.png",
  "alts": [
   "A",
   "B",
   "C",
   "D",
   "E"
  ],
  "texto": "48) (M120029I7) Cássio trabalha como pesquisador e, para a realização de um experimento, anotou as temperaturas registradas por uma estação meteorológica. A tabela abaixo apresenta as anotações do tempo decorrido, em horas, do início da observação dessas temperaturas. Tempo decorrido Temperatura (em horas) (°C) 1 12 2 10 3 8 4 6 A partir dos dados dessa tabela, Cássio percebeu que poderia estabelecer uma função polinomial do 1° grau que relaciona o tempo decorrido, em horas, representado por x, e a temperatura, em °C, representada por f(x). A lei de formação dessa função está representada em A) f(x) = – 2x + 14. 1 25 B) f(x) = - x + . 2 2 1 C) f(x) = - x + 7. 2 D) f(x) = x + 12. E) f(x) = x – 2."
 },
 {
  "ano": "2022",
  "num": 49,
  "cod": "M101371I7",
  "img": "imagens/2022/questao49.png",
  "alts": [
   "A",
   "B",
   "C",
   "D",
   "E"
  ],
  "texto": "49) (M101371I7) Uma estrutura metálica em formato de triângulo retângulo será reforçada com a soldagem de uma nova barra de metal. Essa barra será fixada na posição do segmento que representa a altura h, relativa à hipotenusa desse triângulo, conforme ilustrado na figura abaixo. m 0,4 m 0,9 h Qual é a medida, em metros, dessa nova barra de metal que será soldada nessa estrutura? A) 0,28 m. B) 0,36 m. C) 0,40 m. D) 0,50 m. E) 0,60 m. BL02M12 27"
 },
 {
  "ano": "2022",
  "num": 50,
  "cod": "M120022I7",
  "img": "imagens/2022/questao50.png",
  "alts": [
   "A",
   "B",
   "C",
   "D",
   "E"
  ],
  "texto": "50) (M120022I7) Considere uma função polinomial f do 1º grau, f: IR IR, cujo gráfico está representado abaixo. y 5 4 3 2 1 –5 –4 –3 –2 –1 0 1 2 3 4 5 x –1 –2 –3 –4 –5 A lei de formação dessa função f é A) f(x) = – 5x – 2. B) f(x) = – 4x – 22. C) f(x) = – 5 x – 10. 2 D) f(x) = – 2 x – 4. 5 E) f(x) = 6 x + 4. 5"
 },
 {
  "ano": "2022",
  "num": 51,
  "cod": "M121386H6",
  "img": "imagens/2022/questao51.png",
  "alts": [
   "A",
   "B",
   "C",
   "D",
   "E"
  ],
  "texto": "51) (M121386H6) Elaine produz doces artesanais e, em seu catálogo, oferece 8 tipos diferentes de doces. Ela quer começar a vender esses doces em potes, de forma que cada um contenha 5 unidades desses doces, sem repetição de sabor. Para organizar a produção, ela deseja saber quantos potes diferentes conseguirá produzir ao agrupar essas 5 unidades com sabores distintos entre os 8 disponíveis. Quantos tipos de potes de doces diferentes poderão ser produzidos com esses agrupamentos? A) 5. B) 40. C) 56. D) 336. E) 6 720."
 },
 {
  "ano": "2022",
  "num": 52,
  "cod": "M120407H6",
  "img": "imagens/2022/questao52.png",
  "alts": [
   "A",
   "B",
   "C",
   "D",
   "E"
  ],
  "texto": "52) (M120407H6) Uma escola de natação cobra de seus clientes uma mensalidade de R$ 80,00. Além desse valor, o cliente paga, no ato da matrícula, uma taxa de R$ 90,00 para a avaliação médica. Um cliente frequentou essa escola de natação por 11 meses e pagou em dia todas as suas mensalidades. O valor total pago por esse cliente para frequentar a academia nesse período foi A) R$ 880,00. B) R$ 970,00. C) R$ 990,00. D) R$ 1 070,00. E) R$ 1 870,00. BL02M12 28"
 },
 {
  "ano": "2026",
  "num": 28,
  "cod": "",
  "img": "imagens/2026/questao28.png",
  "alts": [
   "A",
   "B",
   "C",
   "D",
   "E"
  ],
  "texto": ""
 },
 {
  "ano": "2026",
  "num": 29,
  "cod": "",
  "img": "imagens/2026/questao29.png",
  "alts": [
   "A",
   "B",
   "C",
   "D",
   "E"
  ],
  "texto": ""
 },
 {
  "ano": "2026",
  "num": 32,
  "cod": "",
  "img": "imagens/2026/questao32.png",
  "alts": [
   "A",
   "B",
   "C",
   "D",
   "E"
  ],
  "texto": ""
 },
 {
  "ano": "2026",
  "num": 33,
  "cod": "",
  "img": "imagens/2026/questao33.png",
  "alts": [
   "A",
   "B",
   "C",
   "D",
   "E"
  ],
  "texto": ""
 },
 {
  "ano": "2026",
  "num": 36,
  "cod": "",
  "img": "imagens/2026/questao36.png",
  "alts": [
   "A",
   "B",
   "C",
   "D",
   "E"
  ],
  "texto": ""
 },
 {
  "ano": "2026",
  "num": 38,
  "cod": "",
  "img": "imagens/2026/questao38.png",
  "alts": [
   "A",
   "B",
   "C",
   "D",
   "E"
  ],
  "texto": ""
 }
];
