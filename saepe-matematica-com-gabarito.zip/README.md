# Revisão SAEPE – Matemática
EREF Iracema Moura de Moraes Veras · Prof. Gabriel Pedro

Plataforma de estudo com as questões de **Matemática** das provas SAEPE 2018, 2019, 2021, 2022 e da Avaliação Formativa 2026.
Cada questão é exibida **exatamente como na prova original** (imagem recortada do PDF, com enunciado, figuras e alternativas) e o estudante marca A–E.

## Estrutura
```
index.html
css/style.css
js/app.js          (funcionamento do site)
js/questoes.js     (lista de questões e caminhos das imagens)
js/gabarito.js     (gabarito de cada questão)
js/explicacoes.js  (explicação de cada questão)
imagens/2018 … 2026/questaoNN.png
imagens/matriz/    (páginas da Matriz enviada)
imagens/logo/logo.png
```

## Questões incluídas
| Prova | Questões |
|---|---|
| SAEPE 2018 | 14 a 26 e 40 a 52 (26) |
| SAEPE 2019 | 27 a 52 (26) |
| SAEPE 2021 | 27 a 52 (26) |
| SAEPE 2022 | 27 a 52 (26) |
| Avaliação Formativa 2026 | 28, 29, 32, 33, 36 e 38 (6) |

A Avaliação Formativa 2026 enviada é uma digitalização com 2 páginas: só essas 6 questões aparecem completas (a 39 está cortada no arquivo).

## Gabarito e explicações
Os PDFs enviados **não trazem gabarito oficial**. O gabarito (`js/gabarito.js`) e a explicação de cada questão (`js/explicacoes.js`) foram elaborados resolvendo as 110 questões a partir do enunciado e das figuras originais.
- No **Banco de Questões**, ao marcar A–E o site mostra se está certo e a explicação; o botão "Ver gabarito" mostra a resposta e a explicação.
- No **Simulado**, o resultado mostra acertos, erros e percentual, e cada questão pode ser aberta para ver o enunciado e a explicação.
- ⚠️ Não é o gabarito oficial do SAEPE: confira antes de usar com os alunos. Para corrigir uma letra, edite `js/gabarito.js`; para ajustar um texto, edite `js/explicacoes.js`.

## Publicar no GitHub Pages
1. Crie um repositório público (ex.: `saepe-matematica`).
2. Envie **todo o conteúdo desta pasta** (mantendo as pastas `css`, `js` e `imagens`).
3. Settings → Pages → Deploy from a branch → `main` / `(root)` → Save.
4. O site abre em `https://SEU_USUARIO.github.io/saepe-matematica/`.

Todos os caminhos são relativos e não há dependências externas (funciona offline).

## Se aparecer "⚠️ IMAGEM NÃO ENCONTRADA"
O aviso mostra o caminho esperado (ex.: `imagens/2018/questao14.png`). Confira se a pasta `imagens` foi enviada junto e se o nome do arquivo está igual.
